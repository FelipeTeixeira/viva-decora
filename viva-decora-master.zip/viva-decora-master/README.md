Ter gulp instalado globalmente - obrigatório

- instalar as dependências = npm install
- executar comando 'gulp' na pasta raiz

OBS:
Devido ao tempo pra conseguir concluir o teste, 
preferi focar nas atividades mais importantes,
listei algumas coisas que eu poderia melhorar:

    - Clicar no overlay do modal e fechar
    - Abrir modal via JS, sem utilizar display none
    - Estruturar váriaveis de cores no SASS
    - Deixar todas avaliações (corações) funcionando corretamente

Nao consegui identificar qual fonte estava no layout, 
por isso utilizei a Roboto que achei mais similar